package com.example.waitingroomlist;

public class DatabaseHelper {
}
