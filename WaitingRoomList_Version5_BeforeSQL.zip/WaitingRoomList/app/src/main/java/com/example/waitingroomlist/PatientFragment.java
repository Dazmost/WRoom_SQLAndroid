package com.example.waitingroomlist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Set;

public class PatientFragment extends Fragment {

    View rootView;

    static final int PATIENT_CONTACT_REQUEST = 1; // The request code.
    static final int MODIFY_PATIENT_REQUEST = 2; // The request code.

    private FloatingActionButton fab;
    public ArrayList<Patient> patients;

    public PatientFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                      Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_patient, container, false);

        patients = new ArrayList<Patient>();
//        patients.add(new Patient(1234, "Steve", 1, 1000, 10000));
//        patients.add(new Patient(4321, "Bob Macquerie", 1, 1000000, 1000000));

//        updateUi(patients); //Update the UI and onclicklistener
        PatientAdapter adapter = new PatientAdapter(getActivity(),patients);
        ListView patientListView = (ListView) rootView.findViewById(R.id.list);
        //patientListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        // Set the adapter onto the view pager
        patientListView.setAdapter(adapter);

        patientListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Patient patient = patients.get(position);
                Log.d("Halim Item", patients.toString()+ "ArraySize: " + Integer.toString(patients.size()) + " Position:" + (Integer.toString(position)));
                System.out.println(patients.toString());

                Intent intentPatientModify = new Intent(getActivity(),ModifyPatientActivity.class);
                intentPatientModify.putExtra("patientList", patients);
                intentPatientModify.putExtra("patientPosition",position);
//                intentPatientModify.putExtra("")
                startActivityForResult(intentPatientModify,MODIFY_PATIENT_REQUEST);
            }
        });



        fab= (FloatingActionButton) rootView.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getActivity(), "Fab Clicked", Toast.LENGTH_LONG).show();

                Intent intent = new Intent(getActivity(),PatientActivity.class);
                intent.putExtra("patientList", patients);
                startActivityForResult(intent,PATIENT_CONTACT_REQUEST);

            }
        });

        return rootView;
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        // Check which request we're responding to
        if (requestCode == PATIENT_CONTACT_REQUEST) {
            // Make sure the request was successful
            if (resultCode == Activity.RESULT_OK) {
                // The user picked a contact.
                // The Intent's data Uri identifies which contact was selected.

                patients=data.getParcelableArrayListExtra("patientList");
                final int newPatientPosition=data.getIntExtra("patientPosition", 0);
                final boolean buttonPress = data.getBooleanExtra("button",false);

                Log.d("Halim", patients.toString()+ " " + Integer.toString(patients.size()));
                System.out.println(patients.toString());

                final ListView patientListView = (ListView) rootView.findViewById(R.id.list);
                // Do something with the contact here (bigger example below)
                PatientAdapter adapter = new PatientAdapter(getActivity(),patients);
//                patientListView = (ListView) findViewById(R.id.list);
                // Set the adapter onto the view pager
                patientListView.setAdapter(adapter);

                if (buttonPress) {
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updateView(newPatientPosition, patientListView);
                        }
                    }, 10);
                }


            }
        }

        // Check which request we're responding to
        if (requestCode == MODIFY_PATIENT_REQUEST) {
            // Make sure the request was successful
            if (resultCode == Activity.RESULT_OK) {
                // The user picked a contact.
                // The Intent's data Uri identifies which contact was selected.


                patients=data.getParcelableArrayListExtra("patientList");
                final int newPatientPosition=data.getIntExtra("patientPosition", 0);
                final boolean buttonPress = data.getBooleanExtra("button",false);

                PatientAdapter adapter = new PatientAdapter(getActivity(),patients);
                final ListView patientListView = (ListView) rootView.findViewById(R.id.list);
                // Set the adapter onto the view pager
                patientListView.setAdapter(adapter);
                //patientListView.smoothScrollToPositionFromTop(newPatientPosition);
                patientListView.setSelection(newPatientPosition);

                if (buttonPress) {
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            updateView(newPatientPosition, patientListView);
                        }
                    }, 10);
                }


            }
        }
    }


    private void updateView(int index, ListView patientListView){
        final PatientAdapter adapter = new PatientAdapter(getActivity(),patients);
        final View v = patientListView.getChildAt(index - patientListView.getFirstVisiblePosition());

        if(v == null)
            return;

        final TextView numberTextView = (TextView) v.findViewById(R.id.number);
        GradientDrawable magnitudeCircle = (GradientDrawable) numberTextView.getBackground();
        int magnitudeColor = R.color.green;
        magnitudeCircle.setColor(ContextCompat.getColor(v.getContext(),magnitudeColor));

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                GradientDrawable magnitudeCircle = (GradientDrawable) numberTextView.getBackground();
                int magnitudeColor = R.color.magnitude1;
                magnitudeCircle.setColor(ContextCompat.getColor(v.getContext(),magnitudeColor));
            }
        }, 2000);

    }

//    private void updateUi (final ArrayList<Patient> patients){
//        PatientAdapter adapter = new PatientAdapter(getActivity(),patients);
//        ListView patientListView = (ListView) rootView.findViewById(R.id.list);
//        //patientListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
//        // Set the adapter onto the view pager
//        patientListView.setAdapter(adapter);
//
//        patientListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                //Patient patient = patients.get(position);???
//                Log.d("Halim Item", patients.toString()+ "ArraySize: " + Integer.toString(patients.size()) + " Position:" + (Integer.toString(position)));
//                System.out.println(patients.toString());
//
//                Intent intentPatientModify = new Intent(getActivity(),ModifyPatientActivity.class);
//                intentPatientModify.putExtra("patientList", patients);
//                intentPatientModify.putExtra("patientPosition",position);
////                intentPatientModify.putExtra("")
//                startActivityForResult(intentPatientModify,MODIFY_PATIENT_REQUEST);
//            }
//        });
//    }

}

